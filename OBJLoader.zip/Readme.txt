To start file run Windows PowerShell.
Find the folder containing Index.html
type http-server.cmd

Go to internet explorer
On the browser type: localhost:8080

Thats it its being run. Congrats!